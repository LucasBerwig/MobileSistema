package com.example.appagenda;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import br.ulbra.appagenda.R;


public class MainActivity extends AppCompatActivity {
    private EditText edtNome;
    private EditText edtCPF;
    private EditText edtFone;
    private Button btnSalvar;
    private PessoaDAO dao;
    private Pessoa pessoa = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicialização dos campos de entrada e do botão
        edtNome = findViewById(R.id.edtNome);
        edtCPF = findViewById(R.id.edtCPF);
        edtFone = findViewById(R.id.edtFone);
        btnSalvar = findViewById(R.id.btnSalvar);
        dao = new PessoaDAO(this);

        // Configuração do listener para o botão salvar
        btnSalvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                salvar(v);
            }
        });

        // Verificação se há um objeto pessoa sendo passado pelo Intent para edição
        Intent it = getIntent();
        if (it.hasExtra("pessoa")) {
            pessoa = (Pessoa) it.getSerializableExtra("pessoa");
            edtNome.setText(pessoa.getNome());
            edtCPF.setText(pessoa.getCpf());
            edtFone.setText(pessoa.getTelefone());
        }
    }

    public void salvar(View view) {
        // Verificação se estamos criando uma nova pessoa ou atualizando uma existente
        if (pessoa == null) {
            // Criação de uma nova pessoa
            pessoa = new Pessoa();
            pessoa.setNome(edtNome.getText().toString());
            pessoa.setCpf(edtCPF.getText().toString());
            pessoa.setTelefone(edtFone.getText().toString());
            long id = dao.inserir(pessoa);
            Toast.makeText(this, "Pessoa inserida no ID de nº: " + id, Toast.LENGTH_LONG).show();
        } else {
            // Atualização de uma pessoa existente
            pessoa.setNome(edtNome.getText().toString());
            pessoa.setCpf(edtCPF.getText().toString());
            pessoa.setTelefone(edtFone.getText().toString());
            dao.atualizar(pessoa);
            Toast.makeText(this, pessoa.getNome() + ", atualizado com sucesso !!!", Toast.LENGTH_LONG).show();
        }

        // Após salvar ou atualizar, retornar à lista de pessoas
        finish();
    }
}